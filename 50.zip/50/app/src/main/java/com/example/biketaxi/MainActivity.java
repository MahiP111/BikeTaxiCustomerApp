package com.example.biketaxi;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private EditText pickupInput;
    private EditText destinationInput;
    private TextView fareText;
    private TextView statusText;

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView makeText(String text, int size, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(Color.rgb(28, 36, 48));
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setPadding(0, dp(6), 0, dp(6));
        return view;
    }

    private EditText makeInput(String hint) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint(hint);
        input.setTextSize(16);
        input.setPadding(dp(12), dp(8), dp(12), dp(8));
        input.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(80, 100, 120)));
        return input;
    }

    private Button makeButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        return button;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(24), dp(22), dp(24));
        page.setBackgroundColor(Color.rgb(247, 249, 252));

        TextView brand = makeText("BIKE TAXI", 14, true);
        brand.setTextColor(Color.rgb(0, 130, 105));
        page.addView(brand);

        TextView title = makeText("Your ride, made simple.", 28, true);
        title.setPadding(0, dp(8), 0, dp(4));
        page.addView(title);

        TextView subtitle = makeText("Book a bike ride in a few simple steps.", 15, false);
        subtitle.setTextColor(Color.rgb(95, 105, 118));
        page.addView(subtitle);

        page.addView(makeText("Pickup location", 16, true));
        pickupInput = makeInput("Enter pickup address");
        page.addView(pickupInput, new LinearLayout.LayoutParams(-1, dp(54)));

        page.addView(makeText("Destination", 16, true));
        destinationInput = makeInput("Where do you want to go?");
        page.addView(destinationInput, new LinearLayout.LayoutParams(-1, dp(54)));

        Button fareButton = makeButton("Estimate fare");
        page.addView(fareButton, new LinearLayout.LayoutParams(-1, dp(52)));
        fareText = makeText("Estimated fare: —", 18, true);
        fareText.setPadding(0, dp(12), 0, dp(12));
        page.addView(fareText);

        Button bookButton = makeButton("Book a bike taxi");
        page.addView(bookButton, new LinearLayout.LayoutParams(-1, dp(54)));

        statusText = makeText("Ready when you are. This starter app uses demo booking only.", 14, false);
        statusText.setTextColor(Color.rgb(80, 91, 105));
        statusText.setPadding(0, dp(14), 0, dp(8));
        page.addView(statusText);

        TextView note = makeText("Prototype version • No live drivers or payments connected yet", 12, false);
        note.setTextColor(Color.rgb(115, 123, 134));
        page.addView(note);

        fareButton.setOnClickListener(v -> {
            if (!validInputs()) return;
            fareText.setText("Estimated fare: ₹49–₹99*");
            statusText.setText("*Demo estimate only. Actual fares require distance and pricing services.");
        });

        bookButton.setOnClickListener(v -> {
            if (!validInputs()) return;
            String pickup = pickupInput.getText().toString().trim();
            String destination = destinationInput.getText().toString().trim();
            statusText.setText("Demo request created!\nFrom: " + pickup + "\nTo: " + destination
                    + "\n\nNo driver has been contacted. Backend integration is the next step.");
            Toast.makeText(this, "Demo booking created", Toast.LENGTH_SHORT).show();
        });

        scroll.addView(page);
        setContentView(scroll);
    }

    private boolean validInputs() {
        String pickup = pickupInput.getText().toString().trim();
        String destination = destinationInput.getText().toString().trim();
        if (pickup.isEmpty() || destination.isEmpty()) {
            Toast.makeText(this, "Enter both pickup and destination", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (pickup.equalsIgnoreCase(destination)) {
            Toast.makeText(this, "Pickup and destination must be different", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
