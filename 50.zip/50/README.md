# Bike Taxi Customer App — Starter APK Project

This is a starter Android app project intended to be built from a mobile browser using GitHub Actions. Android Studio is not required.

## Included
- Pickup and destination fields
- Demo fare estimate
- Demo booking confirmation
- GitHub Actions workflow that builds a debug APK and uploads it as an artifact

## Important limitations
This is a prototype only. It does not yet include GPS/maps, a backend, live driver matching, phone authentication, payments, or a driver app. The displayed fare is a placeholder, not a real quote.

## Build using a phone
1. Sign in to GitHub and create a new repository.
2. Upload the contents of this ZIP into the repository (upload files/folders, not the ZIP itself).
3. Commit the files to the `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Build Bike Taxi APK** and tap **Run workflow**. (A push to `main` also triggers a build.)
6. Wait for the run to finish successfully.
7. Open the completed workflow run, find **Artifacts**, and download `bike-taxi-customer-debug-apk`.
8. Extract the downloaded artifact ZIP to get `app-debug.apk`.
9. Open the APK on your Android phone to install it. Android may ask you to allow installation from that browser/file manager.

## Package details
- Application ID: `com.example.biketaxi`
- Minimum Android: Android 6.0 (API 23)
- Build type: debug APK (for testing, not Play Store release)

## If the build fails
Open the workflow run and review the failed step's logs. The first build may need a retry if a dependency download times out.
